qemu.utils package
==================

This package provides miscellaneous utilities used for testing and
debugging QEMU. It is used primarily by the vm and avocado tests.

See the documentation in ``__init__.py`` for more information.
