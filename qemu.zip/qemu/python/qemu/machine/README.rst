qemu.machine package
====================

This package provides core utilities used for testing and debugging
QEMU. It is used by the iotests, vm tests, avocado tests, and several
other utilities in the ./scripts directory. It is not a fully-fledged
SDK and it is subject to change at any time.

See the documentation in ``__init__.py`` for more information.
