QEMU Python Namespace
=====================

This directory serves as the root of a `Python PEP 420 implicit
namespace package <https://www.python.org/dev/peps/pep-0420/>`_.

Each directory below is assumed to be an installable Python package that
is available under the ``qemu.<package>`` namespace.
