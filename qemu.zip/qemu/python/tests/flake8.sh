#!/bin/sh -e
python3 -m flake8 qemu/
python3 -m flake8 scripts/
