#!/bin/sh -e
python3 -m isort -c qemu/
python3 -m isort -c scripts/
