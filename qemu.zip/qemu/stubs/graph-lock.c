#include "qemu/osdep.h"
#include "block/graph-lock.h"

void register_aiocontext(AioContext *ctx)
{
}

void unregister_aiocontext(AioContext *ctx)
{
}
