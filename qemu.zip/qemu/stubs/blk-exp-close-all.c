#include "qemu/osdep.h"
#include "block/export.h"

/* Only used in programs that support block exports (libblockdev.fa) */
void blk_exp_close_all(void)
{
}
