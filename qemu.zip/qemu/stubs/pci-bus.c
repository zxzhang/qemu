#include "qemu/osdep.h"
#include "hw/pci/pci.h"

PCIDevice *pci_create_simple(PCIBus *bus, int devfn, const char *name)
{
    g_assert_not_reached();
}
