#include "qemu/osdep.h"
#include "hw/isa/isa.h"

ISADevice *isa_create_simple(ISABus *bus, const char *name)
{
    g_assert_not_reached();
}
