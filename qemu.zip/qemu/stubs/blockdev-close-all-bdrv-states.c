#include "qemu/osdep.h"
#include "block/block_int.h"

void blockdev_close_all_bdrv_states(void)
{
}
