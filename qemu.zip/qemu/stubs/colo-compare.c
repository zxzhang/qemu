#include "qemu/osdep.h"
#include "qemu/notify.h"
#include "net/colo-compare.h"

void colo_compare_cleanup(void)
{
}
