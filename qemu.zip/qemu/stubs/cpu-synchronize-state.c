#include "qemu/osdep.h"
#include "sysemu/hw_accel.h"

void cpu_synchronize_state(CPUState *cpu)
{
}
void cpu_synchronize_post_init(CPUState *cpu)
{
}
