#include "qemu/osdep.h"

const MonitorDef *target_monitor_defs(void);

const MonitorDef *target_monitor_defs(void)
{
    return NULL;
}
