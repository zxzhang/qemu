#include "qemu/osdep.h"
#include "exec/gdbstub.h"       /* gdb_static_features */

const GDBFeature gdb_static_features[] = {
  { NULL }
};
